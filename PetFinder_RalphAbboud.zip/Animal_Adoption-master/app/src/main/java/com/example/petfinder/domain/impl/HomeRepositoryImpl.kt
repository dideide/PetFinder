package com.example.petfinder.domain.impl

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.snapshots
import com.example.petfinder.data.Pet
import com.example.petfinder.domain.HomeRepository
import com.example.petfinder.util.DATE_FIELD
import com.example.petfinder.util.FULLNAME_FIELD
import com.example.petfinder.util.IMAGE_URL_FIELD
import com.example.petfinder.util.POSTS_COLL
import com.example.petfinder.utill.Resource
import com.example.petfinder.util.SENDER_FIELD
import com.example.petfinder.util.USERS_COLL
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.ktx.toObject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

private const val LOG_TAG = "HomeRepo"

@Suppress("DEPRECATION")
class HomeRepositoryImpl @Inject constructor(private val firestore: FirebaseFirestore) :
    HomeRepository {

    override suspend fun getUserName(documentId: String): Resource<String?> {
        return try {
            val userName =
                firestore.collection(USERS_COLL).document(documentId).get().await().data
            Resource.Success(userName?.get(FULLNAME_FIELD) as String?)
        } catch (e: FirebaseFirestoreException) {
            Log.e(LOG_TAG, "Fail to get full name", e)
            Resource.Error(e.message.toString())
        }
    }

    override suspend fun getAllPost(): Resource<Flow<List<Pet>>> {
      return try {
        val docRef = firestore.collection(POSTS_COLL)
            .orderBy(DATE_FIELD, Query.Direction.DESCENDING)



        val result = docRef.snapshots().map {
            it.toObjects(Pet::class.java).map { pet ->
                pet.copy(
                    sender = firestore.collection(USERS_COLL)
                        .document(pet.sender!!)
                        .get().await()
                        .get(FULLNAME_FIELD) as String,
                    //get the id of the post
                    id = it.documents[0].reference.path

                )
            }
        }

        Resource.Success(result)
    } catch (e: FirebaseFirestoreException) {
        Log.e(LOG_TAG, "Fail to get all post", e)
        Resource.Error(e.message.toString())
    }
          

    }


    private suspend fun DocumentSnapshot.toPost(): Pet? {
        return toObject<Pet>()?.copy(
            id = id,
        )
    }
}
