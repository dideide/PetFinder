package com.example.petfinder.data

data class Contact(
    val id: String = "",
    val name: String = "",
    val latestChat: Chat
)
