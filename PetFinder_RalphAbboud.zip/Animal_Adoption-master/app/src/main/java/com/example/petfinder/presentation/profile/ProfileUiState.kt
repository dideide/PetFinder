package com.example.petfinder.presentation.profile

import com.example.petfinder.data.User
import com.example.petfinder.utill.UiText

data class ProfileUiState(
    val user: User,
    val error: UiText? = null
)
