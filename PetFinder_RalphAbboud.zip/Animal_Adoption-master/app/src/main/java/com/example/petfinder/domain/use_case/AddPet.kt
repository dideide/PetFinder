package com.example.petfinder.domain.use_case

import com.example.petfinder.domain.repository.PetRepository

class AddPet(
    private  val repo: PetRepository
) {
    suspend operator fun invoke(
        name: String,
        breed: String,
        age: String,
        personality: String,
        species: String,
        location: String,
        
    )= repo.addPetToFirestore(name,breed,age,personality,species,location)
}