package com.example.petfinder.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import com.example.petfinder.R
import com.example.petfinder.data.User
import com.example.petfinder.domain.AuthRepository
import com.example.petfinder.domain.ProfileRepository
import com.example.petfinder.utill.Resource
import com.example.petfinder.utill.UiText
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val repository: ProfileRepository,
    private val authRepository: AuthRepository
) :
    ViewModel() {

    val auth = Firebase.auth
    private val _userState = MutableStateFlow(ProfileUiState(User("Guest")))
    val userState = _userState.asStateFlow()

    init {
        getData()
    }

    private fun getData() {
        viewModelScope.launch {
            auth.currentUser?.uid?.let {
                repository.getUserName(it).let { result ->
                    when (result) {
                        is Resource.Error -> _userState.emit(
                            ProfileUiState(
                                User("Guest"),
                                UiText.StringResource(R.string.fetch_error)
                            )
                        )

                        is Resource.Success -> _userState.emit(
                            ProfileUiState(
                                User(
                                    result.data,
                                    auth.currentUser?.email
                                )
                            )
                        )
                    }
                }
            }
        }
    }

    fun logOut() {
        auth.signOut()
        runBlocking {
            authRepository.createAnonymous()
            delay(1500)
        }
    }
}