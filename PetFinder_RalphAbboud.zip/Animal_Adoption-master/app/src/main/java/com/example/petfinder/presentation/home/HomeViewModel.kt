package com.example.petfinder.presentation.home

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import com.example.petfinder.R
import com.example.petfinder.domain.HomeRepository
import com.example.petfinder.utill.Resource
import com.example.petfinder.utill.UiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: HomeRepository) : ViewModel() {
    private val currentUser = Firebase.auth.currentUser

    var searchText by mutableStateOf("")
        private set

    private val _user = MutableStateFlow(HomeUiState.User())
    val user = _user.asStateFlow()

    private val _postsState = MutableStateFlow(HomeUiState.Posts())
    val postsState = _postsState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            currentUser?.uid?.let {
                if (!currentUser.isAnonymous)
                    _user.emit(repository.getUserName(it).let { result ->
                        when (result) {
                            is Resource.Error -> HomeUiState.User(error = null)
                            is Resource.Success -> HomeUiState.User(result.data)
                        }
                    })
            }

            repository.getAllPost().let { result ->
                Log.e("lets follow here", result.toString())

                when (result) {
                    is Resource.Error -> _postsState.emit(

                        HomeUiState.Posts(
                            error =
                                UiText.StringResource(R.string.fetch_error)

                        )
                    )

                    is Resource.Success -> result.data?.collect {
                        Log.e("and here", it.toString())
                        _postsState.emit(HomeUiState.Posts(it))
                    }
                }
            }
        }
    }

    fun setSearch(text: String) {
        searchText = text
    }

    fun clearSearch() {
        searchText = ""
    }
}