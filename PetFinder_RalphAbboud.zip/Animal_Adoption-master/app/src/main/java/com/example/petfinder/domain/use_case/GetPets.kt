package com.example.petfinder.domain.use_case

import com.example.petfinder.domain.repository.PetRepository

class GetPets (
    private val repo: PetRepository
) {
    operator fun invoke() = repo.getPetsFromFirestore()

}