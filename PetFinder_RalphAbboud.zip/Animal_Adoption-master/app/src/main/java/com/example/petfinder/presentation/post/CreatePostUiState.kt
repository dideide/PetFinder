package com.example.petfinder.presentation.post

import android.net.Uri
import com.example.petfinder.utill.UiText

data class CreatePostUiState(
    val name: String = "",
    val location: String = "",
    val personality: String = "",
    val cate: String = "adopt",
    val imageUri: Uri? = null,
    val tags: String = ""
)

data class CreatePostErrorState(
    val title: UiText = UiText.DynamicString(""),
    val location: UiText = UiText.DynamicString(""),
    val description: UiText = UiText.DynamicString(""),
    val tags: UiText = UiText.DynamicString("")
)
