package com.example.petfinder.utill

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SharedViewModel():ViewModel() {
    fun saveData(
        userData: User,
        context: Context
    )= CoroutineScope(Dispatchers.IO).launch {
        val firestoreRef = Firebase.firestore.collection("users").document(userData.userID)
        try {
            firestoreRef.set(userData).addOnSuccessListener {
                Toast.makeText(context, "Successfully saved data", Toast.LENGTH_SHORT).show()

            }
        }catch (e:Exception){
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }
}