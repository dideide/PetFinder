package com.example.petfinder.domain

import com.example.petfinder.data.Pet
import com.example.petfinder.utill.Resource
import kotlinx.coroutines.flow.Flow

interface SearchRepository {
    suspend fun getAllPostsWhereTags(tags: List<String>): Resource<Flow<List<Pet>>>
}