package com.example.petfinder.domain.impl

import android.net.Uri
import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ktx.snapshots
import com.google.firebase.storage.FirebaseStorage
import com.example.petfinder.data.Pet
import com.example.petfinder.domain.PostRepository
import com.example.petfinder.util.DATE_FIELD
import com.example.petfinder.util.DONE_FIELD
import com.example.petfinder.util.POSTS_COLL
import com.example.petfinder.utill.Resource
import com.example.petfinder.util.USERS_COLL
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

private const val LOG_TAG = "PostRepo"

class PostRepositoryImpl @Inject constructor(
    private val storage: FirebaseStorage,
    private val firestore: FirebaseFirestore
) : PostRepository {
    override suspend fun uploadPost(
        userId: String,
        name: String,
        location: String,
        personality: String,
        cate: String,
        tags: List<String>,
        imageUri: Uri?,
    ): Resource<Unit> {
        return try {
//      Upload image to cloud storage
            val storageRef = storage.reference
                .child("postImg")
                .child("$userId-${System.currentTimeMillis()}")
            var newPet = Pet(
                title = name,
                location = location,
                content = personality,
                sender = userId,
                date = Timestamp.now(),
                tags = tags,
                cate = cate,
                imageUrl = null,
            )
            imageUri?.let {
                newPet = newPet.copy(
                    imageUrl = storageRef.putFile(it).await()
                        .storage.downloadUrl.await().toString()
                )
            }

            firestore.collection(USERS_COLL).document(userId)
                .collection(POSTS_COLL).document().set(newPet).await()
            firestore.collection(POSTS_COLL).document().set(newPet).await()
            Log.i(LOG_TAG, "Post uploaded")

            Resource.Success(Unit)
        } catch (e: FirebaseFirestoreException) {
            Log.e(LOG_TAG, "Post fail to upload", e)
            Resource.Error(message = e.message.toString())
        }
    }

    override suspend fun getMyPosts(userId: String): Resource<Flow<List<Pet>>> {
        return try {
            val result = firestore.collection(USERS_COLL).document(userId)
                .collection(POSTS_COLL)
                .whereEqualTo(DONE_FIELD, false)
                .orderBy(DATE_FIELD).snapshots()
                .map { querySnapshot ->
                    val list = mutableListOf<Pet>()
                    for (query in querySnapshot) {
                        list.add(
                            query.toObject(Pet::class.java).copy(
                                id = query.id
                            )
                        )
                    }
                    return@map list
                }

            Resource.Success(result)
        } catch (e: FirebaseFirestoreException) {
            Log.e(LOG_TAG, "Fail to get my post", e)
            Resource.Error(e.message.toString())
        }
    }

    override suspend fun deletePost(
        userId: String,
        documentId: String
    ): Resource<Unit> {
        return try {
            firestore.collection(USERS_COLL).document(userId)
                .collection(POSTS_COLL).document(documentId)
                .update(DONE_FIELD, true).await()
            Resource.Success(Unit)
        } catch (e: FirebaseFirestoreException) {
            Log.e(LOG_TAG, "Fail To delete", e)
            Resource.Error(message = e.message.toString())
        }
    }
}