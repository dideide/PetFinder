package com.example.petfinder.domain

import com.example.petfinder.data.Pet
import com.example.petfinder.utill.Resource
import kotlinx.coroutines.flow.Flow

interface HomeRepository {
    suspend fun     getAllPost(): Resource<Flow<List<Pet>>>
    suspend fun getUserName(documentId: String): Resource<String?>
}