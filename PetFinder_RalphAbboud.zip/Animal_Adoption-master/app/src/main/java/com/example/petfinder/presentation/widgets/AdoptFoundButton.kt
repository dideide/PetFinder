package com.example.petfinder.presentation.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.petfinder.presentation.theme.PetTheme

@Composable
fun LostFoundButton(
    modifier: Modifier = Modifier,
    onLostClick: () -> Unit = {},
    onFoundClick: () -> Unit = {},
    enableLost: Boolean = true,
    enableFound: Boolean = true,
    lostChecked: Boolean = true,
    foundChecked: Boolean = true,
    role: Role = Role.RadioButton
) {
    Row(modifier = modifier) {
        Box(
//            ButtonDefaults.buttonColors(
//                containerColor = MaterialTheme.colorScheme.surfaceVariant,
//                contentColor = MaterialTheme.colorScheme.onSurface,
//                disabledContainerColor = MaterialTheme.colorScheme.primary,
//                disabledContentColor = MaterialTheme.colorScheme.onPrimary
//            ),
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (lostChecked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSecondaryContainer
                )
                .weight(1f)
                .height(32.dp)
                .padding(horizontal = 24.dp)
                .clickable(enableLost, role = role, onClick = onLostClick)
        ) {
            Text(
                text = "Adopt",
                color = if (lostChecked) MaterialTheme.colorScheme.inversePrimary else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelLarge
            )
        }
        Spacer(modifier = Modifier.width(20.dp))
        Box(
//            colors = ButtonDefaults.buttonColors(
//                containerColor = MaterialTheme.colorScheme.surfaceVariant,
//                contentColor = MaterialTheme.colorScheme.onSurface,
//                disabledContainerColor = MaterialTheme.colorScheme.tertiary,
//                disabledContentColor = MaterialTheme.colorScheme.onTertiary
//            ),
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (foundChecked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.background
                )
                .weight(1f)
                .height(32.dp)
                .padding(horizontal = 24.dp)
                .clickable(enableFound, role = role, onClick = onFoundClick)
        ) {
            Text(
                text = "Found",
                color = if (foundChecked) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Preview
@Composable
fun LostFoundButtonPreview() {
    PetTheme {
        LostFoundButton()
    }
}