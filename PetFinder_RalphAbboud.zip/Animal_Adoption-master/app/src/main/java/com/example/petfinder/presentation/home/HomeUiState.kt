package com.example.petfinder.presentation.home

import com.example.petfinder.data.Pet
import com.example.petfinder.utill.UiText

interface HomeUiState {
    val error: UiText?

    data class Posts(
        val data: List<Pet> = emptyList(),
        override val error: UiText? = null
    ) : HomeUiState

    data class User(
        val name: String? = "Pet Lover",
        override val error: UiText? = null
    ) : HomeUiState
}