package com.example.petfinder.data.repository

import com.google.firebase.firestore.CollectionReference
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import com.example.petfinder.domain.model.Pet
import com.example.petfinder.domain.model.Response.Failure
import com.example.petfinder.domain.model.Response.Success
import com.example.petfinder.domain.repository.PetRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PetsRepositoryImpl @Inject constructor(
    private val petRef: CollectionReference
): PetRepository {
    override fun getPetsFromFirestore() = callbackFlow {
        val snapshotListener = petRef.orderBy("species").addSnapshotListener { snapshot, e ->
            val booksResponse = if (snapshot != null) {
                val books = snapshot.toObjects(Pet::class.java)
                Success(books)
            } else {
                    Failure(e)
            }
            trySend(booksResponse)
        }
        awaitClose {
            snapshotListener.remove()
        }
    }

    override suspend fun addPetToFirestore(
        name: String,
        breed: String,
        age: String,
        personality: String,
        species: String,
        location: String,
    ) = try {
        val id = petRef.document().id
        val pet = Pet(
            id = id,
            name = name,
            breed = breed,
            age = age,
            personality = personality,
            species = species,
            location = location,
        )
        petRef.document(id).set(pet).await()
        Success(true)
    } catch (e: Exception) {
        Failure(e)
    }

    override suspend fun deletePetsFromFirestore(petId: String) = try {
        petRef.document(petId).delete().await()
        Success(true)
    } catch (e: Exception) {
        Failure(e)
    }

}