package com.example.petfinder.domain

import com.example.petfinder.data.Pet
import com.example.petfinder.data.Reply
import com.example.petfinder.utill.Resource
import kotlinx.coroutines.flow.Flow

interface PostRepliesRepository {
    suspend fun getPost(userId: String, postId: String): Resource<Pet>
    suspend fun getReplies(userId: String, postId: String): Resource<Flow<List<Reply>>>
    suspend fun sendReply(
        userId: String,
        postId: String,
        sender: String,
        content: String
    ): Resource<Unit>
}