package com.example.petfinder.di

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.example.petfinder.domain.AuthRepository
import com.example.petfinder.domain.ChatRepository
import com.example.petfinder.domain.HomeRepository
import com.example.petfinder.domain.PostRepliesRepository
import com.example.petfinder.domain.PostRepository
import com.example.petfinder.domain.ProfileRepository
import com.example.petfinder.domain.SearchRepository
import com.example.petfinder.domain.impl.AuthRepositoryImpl
import com.example.petfinder.domain.impl.ChatRepositoryImpl
import com.example.petfinder.domain.impl.HomeRepositoryImpl
import com.example.petfinder.domain.impl.PostRepliesRepositoryImpl
import com.example.petfinder.domain.impl.PostRepositoryImpl
import com.example.petfinder.domain.impl.ProfileRepositoryImpl
import com.example.petfinder.domain.impl.SearchRepositoryImpl
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun providesFirebaseAuth() = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun providesFirestore() = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun providesStorage() = FirebaseStorage.getInstance()

    @Provides
    @Singleton
    fun providesAuthRepository(
        firebaseAuth: FirebaseAuth,
        firestore: FirebaseFirestore
    ): AuthRepository =
        AuthRepositoryImpl(firebaseAuth, firestore)

    @Provides
    @Singleton
    fun providesHomePostRepository(firebaseFirestore: FirebaseFirestore): HomeRepository =
        HomeRepositoryImpl(firebaseFirestore)

    @Provides
    @Singleton
    fun providesProfileRepository(firestore: FirebaseFirestore): ProfileRepository =
        ProfileRepositoryImpl(firestore)

    @Provides
    @Singleton
    fun providesPostRepository(
        storage: FirebaseStorage,
        firestore: FirebaseFirestore
    ): PostRepository = PostRepositoryImpl(storage, firestore)

    @Provides
    @Singleton
    fun providesPostRepliesRepository(
        firestore: FirebaseFirestore,
    ): PostRepliesRepository = PostRepliesRepositoryImpl(firestore)

    @Provides
    @Singleton
    fun providesSearchRepository(firestore: FirebaseFirestore): SearchRepository =
        SearchRepositoryImpl(firestore)

    @Provides
    @Singleton
    fun providesChatRepository(firestore: FirebaseFirestore): ChatRepository =
        ChatRepositoryImpl(firestore)
}