package com.example.petfinder.presentation.theme

import androidx.compose.ui.graphics.Color

val Red600 = Color(0XFFD6252D)
val Red500 = Color(0XFFEE2E3B)
val Green600 = Color(0XFF059669)
val WhiteSmoke = Color(0XFFF5F5F5)

val LightBlue = Color(0xFF76A5AF)

val Gray50 = Color(0xFFFDFDFD)
val Gray800 = Color(0XFF353333)
val Gray900 = Color(0XFF2A2828)
val Gray950 = Color(0X800F0F0F)