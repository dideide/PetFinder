package com.example.petfinder.domain

import android.net.Uri
import com.example.petfinder.data.Pet
import com.example.petfinder.utill.Resource
import kotlinx.coroutines.flow.Flow

interface PostRepository {
    suspend fun uploadPost(
        userId: String,
        name: String,
        location: String,
        personality: String,
        cate: String,
        tags: List<String>,
        imageUri: Uri?,
    ): Resource<Unit>

    suspend fun getMyPosts(userId: String): Resource<Flow<List<Pet>>>
    suspend fun deletePost(userId: String, documentId: String): Resource<Unit>
}