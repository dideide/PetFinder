package com.example.petfinder.domain.model

data class Pet(
    var id: String? = null,
    var name: String? = null,
    var breed: String? = null,
    var age: String? = null,
    var personality: String? = null,
    var species: String? = null,
    var location: String? = null,

    
)
