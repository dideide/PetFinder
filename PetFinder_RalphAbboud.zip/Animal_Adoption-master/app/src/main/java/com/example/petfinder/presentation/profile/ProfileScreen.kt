package com.example.petfinder.presentation.profile

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController

import com.example.petfinder.R
import com.example.petfinder.presentation.LocalCoroutineScope
import com.example.petfinder.presentation.LocalSnackbarHostState
import com.example.petfinder.presentation.widgets.Navbar
import com.example.petfinder.util.Screen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val userState by viewModel.userState.collectAsState()
    val snackbarHostState = LocalSnackbarHostState.current
    val coroutineScope = LocalCoroutineScope.current
    val logoutMsg = stringResource(R.string.have_logout)

    Scaffold(
        bottomBar = { Navbar(navController) },
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier
                .padding(it)
                .padding(horizontal = 16.dp, vertical = 24.dp)
        ) {
            ProfileBanner(userState.user.fullName ?: "Guest", userState.user.email ?: "")
            Spacer(modifier = Modifier.height(24.dp))
            if (viewModel.auth.currentUser?.isAnonymous == false) {
                ProfileMenu(
                    iconRes = Icons.Default.Message,
                    labelRes = R.string.messages,
                    trailingIconRes = Icons.Default.ArrowForward,
                    borderWidth = 1.dp,
                    modifier = Modifier.clickable {
                        navController.navigate(Screen.Contact.route)
                    }
                )
                Spacer(modifier = Modifier.height(14.dp))
                ProfileMenu(
                    iconRes = Icons.Default.Article,
                    labelRes = R.string.my_posts,
                    trailingIconRes = Icons.Default.ArrowForward,
                    borderWidth = 1.dp,
                    modifier = Modifier.clickable {
                        navController.navigate(Screen.MyPost.route)
                    }
                )
                Divider(Modifier.padding(top = 14.dp, bottom = 14.dp))
                ProfileMenu(
                    iconRes = Icons.Default.Logout,
                    labelRes = R.string.logout,
                    color = MaterialTheme.colorScheme.primary,
                    borderWidth = 1.dp,
                    modifier = Modifier.clickable {
                        viewModel.logOut()
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(logoutMsg)
                        }
                        navController.navigate(Screen.Home.route) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    }
                )
            } else {
                ProfileMenu(
                    iconRes = Icons.Default.Login,
                    labelRes = R.string.login,
                    borderWidth = 1.dp,
                    modifier = Modifier.clickable {
                        navController.navigate(Screen.Login.route)
                    }
                )
            }
        }
    }
}