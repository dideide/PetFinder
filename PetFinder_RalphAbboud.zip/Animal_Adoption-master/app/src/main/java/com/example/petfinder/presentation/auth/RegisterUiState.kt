package com.example.petfinder.presentation.auth

import com.example.petfinder.utill.UiText

data class RegisterUiState(
    val email: String = "",
    val password: String = "",
    val rePassword: String = "",
    val passwordVisible: Boolean = false,
    val fullName: String = ""
)

data class RegisterErrorState(
    val email: UiText = UiText.DynamicString(""),
    val password: UiText = UiText.DynamicString(""),
    val rePassword: UiText = UiText.DynamicString(""),
    val fullName: UiText = UiText.DynamicString(""),
)
