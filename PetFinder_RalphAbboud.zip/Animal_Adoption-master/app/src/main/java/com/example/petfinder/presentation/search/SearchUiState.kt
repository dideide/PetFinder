package com.example.petfinder.presentation.search

import com.example.petfinder.data.Pet
import com.example.petfinder.utill.UiText

data class SearchUiState(
    val data: List<Pet> = emptyList(),
    val cateFilter: String = "",
    val error: UiText? = null
)