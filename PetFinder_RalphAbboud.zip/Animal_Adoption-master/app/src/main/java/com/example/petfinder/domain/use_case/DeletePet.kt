package com.example.petfinder.domain.use_case

import com.example.petfinder.domain.repository.PetRepository

class DeletePet(
    private val repo: PetRepository
) {
    suspend operator fun invoke(petId: String) = repo.deletePetsFromFirestore(petId)
}