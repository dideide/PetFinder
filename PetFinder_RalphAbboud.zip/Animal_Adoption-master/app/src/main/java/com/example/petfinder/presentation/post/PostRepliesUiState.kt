package com.example.petfinder.presentation.post

import com.example.petfinder.data.Pet
import com.example.petfinder.data.Reply
import com.example.petfinder.utill.UiText

sealed interface PostRepliesUiState {
    val error: UiText?

    data class PostState(
        val pet: Pet = Pet(),
        override val error: UiText? = null
    ) : PostRepliesUiState

    data class RepliesState(
        val replies: List<Reply> = emptyList(),
        override val error: UiText? = null
    ) : PostRepliesUiState
}
