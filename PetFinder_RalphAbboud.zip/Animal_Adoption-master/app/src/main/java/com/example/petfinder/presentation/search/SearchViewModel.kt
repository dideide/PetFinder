package com.example.petfinder.presentation.search

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import com.example.petfinder.R
import com.example.petfinder.data.Pet
import com.example.petfinder.domain.SearchRepository
import com.example.petfinder.utill.Resource
import com.example.petfinder.utill.UiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: SearchRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _petData = MutableStateFlow<List<Pet>>(emptyList())
    private val _uiState = MutableStateFlow(SearchUiState())
    val postsState = _uiState.asStateFlow()

    var searchText by mutableStateOf<String>(checkNotNull(savedStateHandle["search"]))
        private set
    var undoClear by mutableStateOf("")
        private set

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            repository.getAllPostsWhereTags(searchText.split(", ", ",")).let { result ->
                when (result) {
                    is Resource.Error -> _uiState.emit(
                        SearchUiState(
                            error = UiText.StringResource(
                                R.string.fetch_error
                            )
                        )
                    )

                    is Resource.Success -> result.data?.collect {
                        _uiState.emit(SearchUiState(it))
                        _petData.emit(it)
                    }
                }
            }
        }
    }

    fun setSearch(value: String) {
        searchText = value
    }

    fun clearSearch() {
        undoClear = searchText
        searchText = ""
    }

    fun filterPost(cate: String) {
        viewModelScope.launch {
            if (_uiState.value.cateFilter == cate) {
                _uiState.update {
                    it.copy(data = _petData.value, cateFilter = "")
                }
            } else {
                _uiState.update {
                    it.copy(
                        cateFilter = cate,
                        data = _petData.value.filter { post ->
                            post.cate == cate
                        }
                    )
                }
            }
        }
    }
}