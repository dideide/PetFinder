package com.example.petfinder.domain.repository

import kotlinx.coroutines.flow.Flow
import com.example.petfinder.domain.model.Pet
import com.example.petfinder.domain.model.Response

typealias Pets = List<Pet>
typealias PetsResponse = Response<Pets>
typealias AddPetResponse = Response<Boolean>
typealias DeletePetResponse = Response<Boolean>


interface PetRepository {
    fun getPetsFromFirestore(): Flow<PetsResponse>

    suspend fun addPetToFirestore(
        name: String,
        breed: String,
        age: String,
        personality: String,
        species: String,
        location: String,
    ): AddPetResponse

    suspend fun deletePetsFromFirestore(petId: String): DeletePetResponse
}