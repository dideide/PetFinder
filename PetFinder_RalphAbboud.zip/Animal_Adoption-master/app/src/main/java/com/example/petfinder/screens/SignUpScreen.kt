package com.example.petfinder.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.petfinder.utill.SharedViewModel

@Composable
fun SignUpScreen(
    navController: NavController,
    sharedViewModel: SharedViewModel

){

}