package com.example.petfinder.presentation.chat

import com.example.petfinder.data.Contact
import com.example.petfinder.utill.UiText

data class ContactUiState(
    val data: List<Contact> = emptyList(),
    val error: UiText? = null
)
