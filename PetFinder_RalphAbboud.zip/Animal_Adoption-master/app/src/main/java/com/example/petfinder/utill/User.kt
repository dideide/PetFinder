package com.example.petfinder.utill

data class User(
    var userID: String = "",
    var name: String = "",
    var email: String = "",
    var password: String = "",
    var phone: String = "",
    var address: String = "",
    var city: String = "",
    var state: String = "",
    var zip: String = "",
    var country: String = "",

)
