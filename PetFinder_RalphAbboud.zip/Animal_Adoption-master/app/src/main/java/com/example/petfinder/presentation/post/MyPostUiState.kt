package com.example.petfinder.presentation.post

import com.example.petfinder.data.Pet
import com.example.petfinder.utill.UiText

data class MyPostUiState(
    val data: List<Pet> = emptyList(),
    val error: UiText? = null
)
