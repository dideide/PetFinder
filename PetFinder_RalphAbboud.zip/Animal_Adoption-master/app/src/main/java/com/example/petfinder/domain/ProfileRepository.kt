package com.example.petfinder.domain

import com.example.petfinder.utill.Resource

interface ProfileRepository {
    suspend fun getUserName(documentId: String): Resource<String?>
}