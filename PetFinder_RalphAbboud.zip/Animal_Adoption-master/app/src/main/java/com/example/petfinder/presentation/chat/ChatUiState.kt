package com.example.petfinder.presentation.chat

import com.example.petfinder.data.Chat
import com.example.petfinder.utill.UiText

data class ChatUiState(
    val currentUserId: String = "",
    val otherUserName: String = "",
    val data: Map<String, List<Chat>> = emptyMap(),
    val error: UiText? = null
)
